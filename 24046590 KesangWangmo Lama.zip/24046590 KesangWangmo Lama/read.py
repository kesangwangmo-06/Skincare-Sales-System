#loads data from the text file and stores it in a dictionary
def load_data():
    """
        loads product data from a tect file into a dictionary
        returns:: dictionary with product ID  as key and product details as value
        example: product_data=load_data
        """
    product_data = {} #creates an empty dictionary
    file = open("data.txt", "r")#opens the file in read mode
    ff = file.readlines()#read all the lines from the file
    item_id = 1
    
    for data in ff:
        data = data.replace("\n", "").split(",")
        product_data[item_id] = data
        item_id += 1#move to the next id
        
    file.close()
    return product_data #returns the complete dictionary
