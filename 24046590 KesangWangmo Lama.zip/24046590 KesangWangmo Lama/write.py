"""
Writes a customer purchase invoice to a text file
parameters:path to the  invoice file, customer name,customer contact number,purchase date and time,list of tuples.shipping,total
example:generate_invoice("invoice.txt", "dolma Lama", "9876543210", datetime.now(),
                         [("eye cream", 2, 500, 1000, 0)], 50, 1050)
"""

def generate_invoice(file_path, name, phone_number, datetime_now, items, shipping_cost, grand_total):
    file = open(file_path, "a")#opens the file in append mode
    file.write("\n" + "="*100 + "\n")
    file.write("\t\t\tWe Care\n")
    file.write("\t\tBoudha, Kathmandu | Phone No: 9841277311\n")
    file.write("-------------------------------------------------------------------------\n")
    file.write("Customer Details:\n")
    file.write("-------------------------------------------------------------------------\n")
    file.write("Name of the Customer: " + name + "\n")
    file.write("Contact number: " + phone_number + "\n")
    file.write("Date and time of purchase: " + str(datetime_now) + "\n")
    file.write("-------------------------------------------------------------------------\n")
    file.write("\nPurchase Detail:\n")
    file.write("------------------------------------------------------------------------------------------------------------------\n")
    file.write("Item Name \t Quantity \t Free \t Unit Price \t Total\n")
    file.write("------------------------------------------------------------------------------------------------------------------\n")
    #write each purchased items details in thew file
    for item in items:
        file.write(item[0] + "\t" + str(item[1]) + "\t\t" + str(item[4]) + "\t\t" + str(item[2]) + "\t\t$" + str(item[3]) + "\n")
    file.write("------------------------------------------------------------------------------------------------------------------\n")
    #shipping cose if applicable
    if shipping_cost > 0:
        file.write("Shipping Cost: $" + str(shipping_cost) + "\n")
    #add the final total
    file.write("Grand Total: $" + str(grand_total) + "\n")
    file.close()

"""
appends a summary of reestocked items to a text file
parameters:path to the invoice file.list of restock tuples. date and time of restock
example:restock_invoice("restock.txt", [("eye Cream", 10, 30, 550)], datetime.now())
"""
def restock_invoice(file_path, restock_records, datetime_now):
    with open(file_path, "a") as file:
        file.write("\n" + "="*100 + "\n")
        file.write("\t\t\tWe Care - Restock Invoice\n")
        file.write("\t\tBoudha, Kathmandu | Phone No: 9841277311\n")
        file.write("-------------------------------------------------------------------------\n")
        file.write("Admin Restock Summary:\n")
        file.write("-------------------------------------------------------------------------\n")
        #write deails for restock products
        for record in restock_records:
            file.write("Product: " + record[0] + "\n")
            file.write("Quantity Added: " + str(record[1]) + "\n")
            file.write("New Total Quantity: " + str(record[2]) + "\n")
            file.write("Updated Price: $" + str(record[3]) + "\n")
            file.write("-------------------------------------------------------------------------\n")
        #add time stamp for the restock
        file.write("Restocked on: " + str(datetime_now) + "\n")
        file.write("="*100 + "\n")
